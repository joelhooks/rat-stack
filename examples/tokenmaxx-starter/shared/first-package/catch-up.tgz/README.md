# A first package someone already started; rename everything

This is someone else's start, not yours. Rename everything: the folder, the tool, the skill, and anything else you keep. Nothing in here is a name you're meant to use.

It's one Pi package: a folder Pi loads tools, skills, prompts and themes from. Pi finds each kind by its folder name (`extensions/`, `skills/`), so it needs no manifest.

- `extensions/wombat-gauge.ts`: a tool, `wombat_gauge`, that runs `pnpm typecheck` and returns the result.
- `skills/wombat-ritual/SKILL.md`: a skill, `wombat-ritual`, that tells the agent to prove a change works before it says "done".

The wombats are placeholders, so nobody keeps them by accident.

`pnpm ex 01.1 catch-up` unpacked it into `.pi/catch-up/01.1/`, which git ignores, and switched on its entry in `.pi/settings.json`. Every fresh Pi in this repo now loads it.

To make it yours, copy it to wherever your own code lives, under a name you choose, and rename what's inside. Point your `.pi/settings.json` at the copy and switch this entry off, so the tool isn't loaded twice. Pi's package docs are in `node_modules/@earendil-works/pi-coding-agent/docs/packages.md`, with `extensions.md` and `skills.md` next to it.

The dev loop: edit a piece, run `/reload` in Pi (or quit and start it again), then try it.
