---
name: wombat-ritual
description: Prove a change works before saying it's done. Use before you tell the user a task is finished, fixed or passing.
---

# Wombat ritual

"Done" is a claim. Back it with evidence from this turn, not from memory.

1. Run the `wombat_gauge` tool. If it fails, fix the errors and run it again.
2. Run the check that matches the task: the exercise's `pnpm ex <id> done`, the tests you touched, or the command the user named.
3. Report what you ran and what it printed. If something failed or you skipped it, say so.

Never weaken a check, a hook or a test to make it pass.
