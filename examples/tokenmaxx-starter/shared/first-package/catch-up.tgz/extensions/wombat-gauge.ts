import type { ExtensionAPI } from "@earendil-works/pi-coding-agent";
import { Type } from "typebox";

// One tool: run the repo's typecheck and hand back what it said, so the agent
// sees a red result instead of guessing it's green. The name is a stand-in:
// rename it.

const keepLast = (text: string, lines: number) =>
  text.trim().split("\n").slice(-lines).join("\n");

export default function wombatGauge(pi: ExtensionAPI) {
  pi.registerTool({
    name: "wombat_gauge",
    label: "Wombat gauge",
    description:
      "Run `pnpm typecheck` in the repo and return whether it passed, with the last lines of its output.",
    promptSnippet: "Run the repo's typecheck and report the result",
    parameters: Type.Object({}),
    async execute(_toolCallId, _params, signal, _onUpdate, ctx) {
      const result = await pi.exec("pnpm", ["typecheck"], {
        cwd: ctx.cwd,
        timeout: 300_000,
        ...(signal === undefined ? {} : { signal }),
      });
      const passed = result.code === 0;
      const output = keepLast(`${result.stdout}\n${result.stderr}`, 40);
      return {
        content: [
          {
            type: "text",
            text: `${passed ? "typecheck passed" : `typecheck failed (exit ${result.code})`}\n${output}`,
          },
        ],
        details: { passed, code: result.code },
      };
    },
  });
}
